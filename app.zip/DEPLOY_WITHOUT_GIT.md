# Deploy backend without Git (e.g. via WinSCP)

You don’t have push access to the HO-backend repo. Here are two ways to get your backend live.

---

## Option 1: Deploy backend on your own server (WinSCP)

Run the API on the **same server** that hosts homeandown.com (or another server you control). Then the frontend can use the same domain and avoid CORS.

### Step 1: Prepare the backend folder

On your PC, the backend is in the `python_api` folder. It should contain:

- `app/` (folder with main.py, routes, etc.)
- `run_render.py` or a run script
- `requirements.txt`

Create a **production** `requirements.txt` that only has what’s needed at runtime (no dev tools like pytest, black). You can copy `requirements.txt` and remove lines like `pytest`, `black`, `flake8`, `mypy` if you want a smaller install. Or use the full file.

### Step 2: Upload via WinSCP

1. Connect to your server with WinSCP (SSH/SFTP).
2. Upload the **whole `python_api` folder** (with `app/`, `requirements.txt`, `run_render.py`) to the server, e.g.:
   - `~/api/` or
   - `public_html/api/` or
   - Any path your host allows for running Python apps.

### Step 3: On the server – install and run

SSH into the server (or use your host’s “SSH” / “Terminal” in cPanel etc.) and run:

```bash
cd /path/to/python_api   # same path you uploaded to

# Use Python 3.11 if possible (same as .python-version)
python3.11 -m venv venv
source venv/bin/activate   # Linux/Mac; on Windows: venv\Scripts\activate

pip install -r requirements.txt
```

Set **environment variables** (same as in your `.env`):

- `SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY`, `JWT_SECRET`, `PYTHON_API_KEY`, `SITE_URL`, `CORS_ORIGIN`, etc.

Then run the app:

```bash
export PORT=8000
# Set other env vars here or in .env on server
python run_render.py
```

Or with gunicorn (better for production):

```bash
pip install uvicorn gunicorn
gunicorn app.main:app -w 1 -k uvicorn.workers.UvicornWorker -b 0.0.0.0:8000
```

Keep this running (e.g. with `screen`, `tmux`, or a process manager like systemd/supervisor).

### Step 4: Expose the API

- **If the API is on the same domain** (e.g. `https://homeandown.com/api`):  
  Configure your web server (Apache/Nginx) to **proxy** `/api` to `http://127.0.0.1:8000` (or the port you use). Then the frontend can call `/api` and CORS is not needed.

- **If the API is on a subdomain** (e.g. `https://api.homeandown.com`):  
  Point the subdomain to this server and proxy to the same port. Then the frontend must use `https://api.homeandown.com` as backend URL (see Step 5).

### Step 5: Rebuild and deploy the frontend

- **Same-domain API (e.g. homeandown.com/api):**  
  Build with:
  ```powershell
  $env:VITE_PY_API_URL="same"; npm run build
  ```
  Then upload the new `dist/` contents via WinSCP to your site’s document root. The app will call `/api/...` on the same origin.

- **Subdomain API (e.g. api.homeandown.com):**  
  Build with:
  ```powershell
  $env:VITE_PY_API_URL="https://api.homeandown.com"; npm run build
  ```
  Then upload the new `dist/` and ensure the backend allows CORS for `https://homeandown.com` and `https://www.homeandown.com` (your current backend code already does).

---

## Option 2: Use your own GitHub repo + Render

If you want to keep using **Render** but don’t have access to PrudhviTexr/HO-backend:

1. Create a **new repo** under **your** GitHub account (e.g. `yourusername/homeandown-backend`).
2. Copy the **contents** of your local `python_api` folder (all files and folders inside it) into that new repo. The repo root should look like: `app/`, `requirements.txt`, `run_render.py`, `.python-version`, etc.
3. Push to that repo.
4. In **Render**: create a **new Web Service**, connect it to **this new repo** (your repo, not PrudhviTexr’s), same build command (`pip install -r requirements.txt`) and start command (`python run_render.py`). Set the same environment variables as before.
5. After deploy, Render will give you a new URL (e.g. `https://your-service.onrender.com`). Build your frontend with that URL:
   ```powershell
   $env:VITE_PY_API_URL="https://your-service.onrender.com"; npm run build
   ```
   Then upload the new `dist/` via WinSCP.

---

## Summary

| Goal                         | What to do |
|-----------------------------|------------|
| No Git access, use your server | Option 1: Upload `python_api` via WinSCP, run on server, proxy `/api` or a subdomain, then build frontend with `VITE_PY_API_URL=same` or the API URL. |
| Keep using Render           | Option 2: New GitHub repo with your backend code, new Render service from that repo, then build frontend with the new Render URL. |
