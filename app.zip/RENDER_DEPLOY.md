# Render backend deploy – HO-backend

Backend repo: **git@github.com:PrudhviTexr/HO-backend.git**  
Render URL: **https://homeandown-backend-p6wa.onrender.com**

---

## 1. Why the backend might “not be working”

| Cause | What to do |
|-------|------------|
| **Old code on Render** | Push latest code to GitHub and trigger a new deploy on Render. |
| **Missing env vars** | In Render Dashboard → Service → Environment, set all required variables (see below). |
| **CORS errors** | Ensure the latest code (with `https://www.homeandown.com` in CORS) is deployed. |
| **Build or start failed** | In Render Dashboard → Logs, check **Build** and **Deploy** logs for errors. |
| **Service sleeping (free tier)** | First request can take 30–60s; frontend uses a 60s timeout for auth. |

---

## 2. Required environment variables on Render

In **Render Dashboard** → your **Web Service** → **Environment**:

| Key | Required | Notes |
|-----|----------|--------|
| `SUPABASE_URL` | Yes | Supabase project URL. |
| `SUPABASE_SERVICE_ROLE_KEY` | Yes | Service role key (long JWT). |
| `JWT_SECRET` | Yes | Secret for signing tokens. |
| `PYTHON_API_KEY` | Yes | API key for admin/backend calls. |
| `SITE_URL` | Recommended | e.g. `https://www.homeandown.com` |
| `CORS_ORIGIN` | Optional | e.g. `https://homeandown.com,https://www.homeandown.com` (code also adds these by default). |
| `GMAIL_USERNAME` | For email | Gmail address. |
| `GMAIL_APP_PASSWORD` | For email | App password. |
| `PORT` | Set by Render | Do not override. |

If `SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY`, or `JWT_SECRET` are missing, the app may start but many routes will fail.

---

## 3. Get latest code to GitHub (for someone with push access)

From a machine where Git is configured for **PrudhviTexr** (or a collaborator):

```bash
cd path/to/python_api
git remote -v
# Should show: origin  git@github.com:PrudhviTexr/HO-backend.git

git add app/main.py app/core/config.py
git status
git commit -m "CORS: production origins; remove debug log"
git push origin main
```

If you use HTTPS and have access:

```bash
git remote set-url origin https://github.com/PrudhviTexr/HO-backend.git
git push origin main
```

The **HO-backend** repo root must look like this (contents of `python_api` at root):

- `app/`
- `run_render.py`
- `requirements.txt`
- `render.yaml`
- (optional) `RENDER_DEPLOY.md`

---

## 4. Redeploy on Render

1. Open **https://dashboard.render.com** and sign in.
2. Open the **Web Service** that runs HO-backend (e.g. `homeandown-api`).
3. **Manual Deploy** → **Deploy latest commit** (or let auto-deploy run after `git push`).
4. Wait for **Build** and **Deploy** to finish (green).
5. Open **Logs** and confirm:
   - No Python tracebacks.
   - A line like: `[CORS] Final allowed origins: [..., 'https://homeandown.com', 'https://www.homeandown.com']`.
   - A line like: `Uvicorn running on http://0.0.0.0:PORT`.

---

## 5. Quick health check

After deploy:

- Open: **https://homeandown-backend-p6wa.onrender.com/api**  
  You should see JSON like: `{"message":"Welcome to Home & Own API - ...","api_endpoint":"/api"}`.

If that URL works but the site still can’t reach the backend, check:

- Frontend is using `https://homeandown-backend-p6wa.onrender.com` (or `VITE_PY_API_URL`).
- No CORS errors in the browser console (F12 → Network / Console).
